import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true,
        lowercase: true,
        trim: true,
        match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email']
    },
    password: {
        type: String,
        required: [true, 'Password is required'],
        minlength: 6,
        select: false
    },
    role: {
        type: String,
        enum: ['student', 'supervisor', 'coordinator', 'panel_member'],
        required: true
    },
    firstName: {
        type: String,
        required: [true, 'First name is required'],
        trim: true
    },
    lastName: {
        type: String,
        required: [true, 'Last name is required'],
        trim: true
    },
    registrationNumber: {
        type: String,
        sparse: true,
        unique: true
    },
    // For students
    degree: {
        type: String,
        enum: ['BSCS', 'BSSE', 'BSIT', 'BSAI', 'BSDS', 'BSCY']
    },
    batch: {
        type: String,
        enum: ['Fall', 'Spring', 'Fa', 'Sp']
    },
    enrolledYear: {
        type: Number
    },
    semester: {
        type: Number,
        default: 7
    },
    rollSequence: {
        type: Number
    },
    // For supervisors and panel members
    domain: [{ type: String, trim: true }],
    designation: {
        type: String,
        trim: true
    },
    phoneNumber: {
        type: String,
        trim: true
    },
    officeAddress: {
        type: String,
        trim: true
    },
    areaOfExpertise: {
        type: String,
        trim: true
    },
    preferredProjectNature: {
        type: String,
        trim: true
    },
    specificTools: {
        type: String,
        trim: true
    },
    interestedProjectTypes: {
        type: String,
        trim: true
    },
    isActive: {
        type: Boolean,
        default: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Hash password before saving
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) {
        return next();
    }

    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
});

// Method to compare passwords
userSchema.methods.comparePassword = async function (candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

// Virtual for full name
userSchema.virtual('fullName').get(function () {
    return `${this.firstName} ${this.lastName}`;
});

export default mongoose.model('User', userSchema);
